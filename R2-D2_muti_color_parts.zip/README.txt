                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2775080
R2-D2 muti color parts by Knickohr is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I modified this robot a little bit to make it printable in different colors. I used the inventor-files and spit it. So, there are now over 100 separate parts for fitting together. Some parts must be rescaled to fit togehter.

I also make the head rotatable, so I designed some extra parts for this. Use an 608 bearing for it.

Share your prints !

# Print Settings

Printer Brand: Prusa
Printer: Prusa Mk2
Rafts: No
Supports: Yes
Resolution: 0.20
Infill: variable infills

Notes: 
Some parts must be printed with support.

If you print R2 in size about 40x25x25cm you need about 1kg of white, 300g of grey, 100g of blue, and some grams of black filament.

Annotation:
I didn't print the brown cable wires because it was a nighmare and did not came out good. Instead I use a 4mm rope ( https://www.ebay.de/itm/322514636372 ).